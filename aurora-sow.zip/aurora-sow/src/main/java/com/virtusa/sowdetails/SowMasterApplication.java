package com.virtusa.sowdetails;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SowMasterApplication {

	public static void main(String[] args) {
		SpringApplication.run(SowMasterApplication.class, args);
	}

}
