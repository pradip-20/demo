package com.virtusa.sowdetails.controllers;

import java.io.IOException;
import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.virtusa.sowdetails.services.SowMasterService;
import com.virtusa.sowdetails.services.SowUploadService;

@RestController
@RequestMapping("/api/citi-portal")
public class SowUploadController {
	
	@Autowired
	private SowUploadService sowUploadService;

	@PostMapping("/uploadFile")
	public String uploadFile(@RequestParam("file") MultipartFile file) throws IllegalStateException, IOException  {
		System.out.println("- - - - - - - - - - - - - - - - - - - - -"+LocalDate.now().toString());
		return sowUploadService.phraseFile(file);
	}
}
